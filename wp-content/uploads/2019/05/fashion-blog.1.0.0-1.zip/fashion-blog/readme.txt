===  Fashion Blog ===

Contributors: madhukar subedi
Tags: blog, news, entertainment, one-column, two-columns, left-sidebar, right-sidebar, post-formats, custom-background, custom-menu, featured-images, full-width-template, custom-header, translation-ready, theme-options, threaded-comments

Requires at least: 4.5
Tested up to: 4.9.4
Stable tag: 1.0.0

== Theme License & Copyright ==
  Fashion Blog is distributed under the terms of the GNU GPL
  Fashion Blog Copyright 2018   Fashion Blog, Madhukar Subedi

License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html


== Description ==
Child Theme of Galway Lite which is a complete blog theme,  here you can get a full width template and different style of color as well as fonts



WordPress theme "Fashion Blog" is a child theme of "galway-lite".
galway-lite Theme is licensed under the GPL3.

License for images:
https://pixabay.com/en/people-female-girl-woman-clothing-2593366/


== 1.0.0  =
* Initial release
